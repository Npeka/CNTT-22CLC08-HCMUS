# Multimedia Album (MMAlbum) System Requirements

Multimedia Album (MMAlbum) is an online multimedia storage service. It provides users with functionality to store and share multimedia objects, such as pictures, audio clips, and video clips.

## Multimedia Objects

A multimedia object has the following common information:

* **Resource ID:** Unique identifier.
* **Name:** Object name.
* **Description:** Object description.
* **File Size:** Size of the multimedia file.
* **Upload Date/Time:** Date and time of upload.
* **Average Rating:** Current average rating score (e.g., 4.5 stars).
* **Downloads/Views:** Total number of downloads/views.
* **Owner:** User account that owns the object.
* **Category:** Category the object belongs to.

There are three types of multimedia objects:

* **Picture:**
    * Width (pixels)
    * Height (pixels)
    * Format (JPG, PNG, BMP...)
* **Audio Clip:**
    * Duration (milliseconds)
    * Quality (mono or stereo)
    * Sampling frequency (e.g., 44.4 kHz)
    * Format (WAV, WMA, MP3...)
* **Video Clip:**
    * Duration (milliseconds)
    * Width (pixels)
    * Height (pixels)
    * Frames per second (FPS)
    * Format (MPEG4, MKV, WMV, FLV...)
    * Thumbnail (optional)

## User Accounts

Users must register an account to use MMAlbum. Each account has the following information:

* **User ID:** Unique identifier.
* **Full Name:** User's full name.
* **Date of Birth:** User's date of birth.
* **Address:** User's address.
* **Telephone Numbers:** User's telephone numbers.
* **Registration Date:** Date of account registration.
* **Latest Renewal Date:** Date of the latest renewal.
* **Expiration Date:** Account expiration date (if applicable).
* **Status:** Account status (valid, expired, banned).
* **Upload Bandwidth:** Total monthly upload bandwidth.
* **Download Bandwidth:** Total monthly download bandwidth.

There are three types of accounts:

* **Regular Account:**
    * Validity: 6 months from registration or renewal.
    * Registration Fee: 10 USD.
    * Renewal Fee: 5 USD.
    * Monthly Bandwidth: 1 GB (total upload and download).
* **Silver Account:**
    * Validity: 12 months from registration or renewal.
    * Registration Fee: 20 USD.
    * Renewal Fee: 10 USD.
    * Monthly Bandwidth: 3 GB upload, 3 GB download.
* **Gold Account:**
    * Validity: 12 months from registration or renewal.
    * Registration Fee: 40 USD.
    * Renewal Fee: 30 USD.
    * Monthly Bandwidth: 20 GB upload, 20 GB download.

## System Functions

* **Account Management:**
    * User registration and renewal.
    * Renewal logging (account ID, renewal date, credit card).
* **Payment Processing:**
    * Credit card information capture (type, number, expiration, owner, security code).
    * Integration with Online Payment Gateway for payment processing.
    * Transaction fees depending on card type.
* **Email Confirmation:**
    * Integration with Express Email Portal to send confirmation emails after registration/renewal.
* **Multimedia Object Management:**
    * Upload new multimedia objects.
    * Update existing multimedia object information.
    * Delete uploaded multimedia objects.
    * Multimedia objects are public by default.
    * Silver and Gold accounts can set objects to private mode.
    * Gold accounts can edit multimedia object content (picture, audio, video).
* **Search and Retrieval:**
    * Search for multimedia objects (excluding private objects of other users).
    * View/download multimedia objects.
    * Rate multimedia objects.
    * Share multimedia objects to Facebook.
* **History Tracking:**
    * View monthly download and upload history.
* **Account Expiration Reminder:**
    * Smart Reminder (external system) sends an SMS message 30 days before account expiration for Silver and Gold accounts.

## External Services

* **Online Payment Gateway:** Processes credit card payments.
* **Express Email Portal:** Sends confirmation emails.
* **Smart Reminder:** Sends SMS reminders for account renewal.
```
