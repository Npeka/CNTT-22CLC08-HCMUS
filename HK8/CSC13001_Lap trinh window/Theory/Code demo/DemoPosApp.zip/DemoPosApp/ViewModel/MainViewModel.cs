﻿using Microsoft.UI.Xaml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoPosApp.ViewModel
{
    public class MainViewModel: INotifyPropertyChanged
    {
        private Window? _host = null;

        public event PropertyChangedEventHandler? PropertyChanged;

        public string Username {get; set;} = "";
        public string Password { get; set;} = "";
        public string Telephone { get; set; } = "";
        public int Balance { get; set; } = 0;
        public string Avatar { get; set; } = "";

        public MainViewModel(Window host) {
            _host = host;
        }

        public bool CanLogin() {
            return Username.IsNotEmpty() && Password.IsNotEmpty();
        }

        public void Login() {
            var screen = new DashboardWindow(Username);
            screen.Activate();

            _host?.Close();
        }
    }
}
