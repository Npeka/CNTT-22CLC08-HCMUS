﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoPosApp
{
    public static class TênNgaauxNhienNhutheOanOCungDuoc
    {
        public static bool IsEmpty(this string info) {
            return info.Length == 0;
        }

        public static bool IsNotEmpty(this string info) {
            return !IsEmpty(info);
        }
    }
}
