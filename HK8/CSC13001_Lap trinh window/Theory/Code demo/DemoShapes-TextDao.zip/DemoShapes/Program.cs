﻿using System.Drawing;

namespace DemoShapes
{
    internal class Program
    {
        public interface IShape {
            
        }

        public interface IVisitable {
            void Accept(IVisitor visitor);
        }

        public interface IVisitor {
            void Visit(Rectangle rect);
            void Visit(Square square);
            void Visit(Triangle triangle);
        }

        public interface IDrawStrategy {
        }

        public class SolidDrawStrategy : IDrawStrategy, IVisitor {
            private void _draw(Rectangle rect, char symbol) {
                Console.WriteLine($"Drawing solid rectangle with symbol {symbol}");
            }

            private void _draw(Square square, char symbol) {
                Console.WriteLine($"Drawing solid square with symbol {symbol}");
            }

             private void _draw(Triangle square, char symbol) {
                Console.WriteLine($"Drawing solid triangle with symbol {symbol}");
            }

            void IVisitor.Visit(Rectangle rect) {
                _draw(rect, '*');
            }

            void IVisitor.Visit(Square square) {
                _draw(square, '*');
            }

            void IVisitor.Visit(Triangle square) {
                _draw(square, '*');
            }
        }

        public class HollowDrawStrategy : IDrawStrategy, IVisitor {
            private void _draw(Rectangle rect, char symbol) {
                Console.WriteLine($"Drawing hollow rectangle with symbol {symbol}");
            }

            private void _draw(Square square, char symbol) {
                Console.WriteLine($"Drawing hollow square with symbol {symbol}");
            }

            private void _draw(Triangle square, char symbol) {
                Console.WriteLine($"Drawing hollow triangle with symbol {symbol}");
            }
            
            
            void IVisitor.Visit(Rectangle rect) {
                _draw(rect, '*');
            }

            void IVisitor.Visit(Square square) {
                _draw(square, '*');
            }

            void IVisitor.Visit(Triangle triangle) {
                _draw(triangle, '*');
            }
        }

        public class Rectangle : IShape, IVisitable {
            public int Width { get; set; }
            public int Height { get; set; }

            public void Draw() {
                for (int i = 0; i < Height; i++)
                {
                    for (int j = 0; j < Width; j++)
                    {
                        Console.Write("*");
                    }
                    Console.Write("\n");
                }
            }

            void IVisitable.Accept(IVisitor visitor) {
                visitor.Visit(this);
            }
        }

        public class Square : IShape, IVisitable {
            public int Side { get; set; }
            public void Draw() {
                 for (int i = 0; i < Side; i++)
                {
                    for (int j = 0; j < Side; j++)
                    {
                        Console.Write("*");
                    }
                    Console.Write("\n");
                }
            }

            void IVisitable.Accept(IVisitor visitor) {
                visitor.Visit(this);
            }
        }

        public class Triangle : IShape, IVisitable {
            public float Side1 { get; set; }
            public float Side2 { get; set; }
            public float Side3 { get; set; }

            void IVisitable.Accept(IVisitor visitor) {
                visitor.Visit(this);
            }
        }

        interface IDao {
            List<IShape> GetAll();
        }

        class MockDao : IDao {
            public List<IShape> GetAll() {
                return new List<IShape> {
                    new Rectangle() { Width = 3, Height = 4 },
                    new Square() { Side = 5 },
                    new Rectangle() { Width = 7, Height = 8 },
                    new Square() { Side = 12 },
                    new Triangle(),
                    new Triangle(),
                };
            }
        }

        class TextDao : IDao {
            string _path = "";
            public TextDao(string path) {
                _path = path;
            }
            public List<IShape> GetAll() {
                throw new NotImplementedException();
            }
        }

        static void Main(string[] args)
        {
            //IDao dao = new MockDao();
            IDao dao = new TextDao("shapes.txt");
            var shapes = dao.GetAll();
    
            Console.WriteLine("Ban muon ve dang gì?");
            Console.WriteLine("  1. Đặc");
            Console.WriteLine("  2. Rỗng");
            var type = int.Parse(Console.ReadLine()!); // TODO: Handle invalid input

            Console.WriteLine("Ban muon ve bang ki tu gi?");
            var symbol = Console.ReadLine()!; // *, + , - , #, $, ®

            IDrawStrategy painter = (type == 1) ? 
                new SolidDrawStrategy() :
                new HollowDrawStrategy();

            for (int i = 0; i < shapes.Count; i++) {
                IShape shape = shapes[i];
                //painter.Draw(shape, symbol[0]);
                ((shape as IVisitable)!).Accept((painter as IVisitor)!) ;


                Console.WriteLine();
            }
        }
    }
}
