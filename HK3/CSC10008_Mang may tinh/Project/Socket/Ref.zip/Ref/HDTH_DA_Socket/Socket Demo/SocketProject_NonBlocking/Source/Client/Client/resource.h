//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Client.rc
//
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_IP                          1000
#define IDC_EDIT2                       1001
#define IDC_USER                        1001
#define IDC_LOGIN                       1002
#define IDC_LOGOUT                      1003
#define IDC_ADD                         1004
#define IDC_SUBTRACT                    1005
#define IDC_EDIT3                       1006
#define IDC_MSGBOX                      1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
