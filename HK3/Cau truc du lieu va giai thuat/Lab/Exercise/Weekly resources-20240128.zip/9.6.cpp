#include<iostream>
#include<time.h>
#include<stdlib.h>
#include<algorithm>
using namespace std;

void inputArray(int* &a, int &n){
	cin >> n;
	a = new int[n];
	for(int i = 0; i < n; ++i)
		a[i] = rand() % 90 + 10;
}

void printArray(int* a, int n){
	for (int i = 0; i < n; ++i)
		cout << a[i] << " ";
	cout << "\n";
}

int* findLongestAscendingSubarray(int* a, int n, int &length)
{
	int len;
	length = 1;
	int pos = 0;

	for(int i = 0; i < n - 1; i += 1){
		
		len = 1;
		
		for (int j = i; j < n - 1; j += 1){
			if (a[j] < a[j + 1]){
				len += 1;
			}
			else
			break;
		}
			
	
	if (len > length){
		length = len;
		pos = i;
		}
	}
	
	int* b = new int[length];
	for (int i = 0; i < length; i += 1)
	{
		b[i] = a[pos + i];
	}
	return b;	
}
void swapArrays(int*& a, int*& b, int &na, int &nb)
{
	int* temp1 = a;
	a = b;
	b = temp1;
	int temp2 = na;
	na = nb;
	nb = temp2;
}

int* concatenate2Arrays(int* a, int* b, int na, int nb)
{
	int * newArr = new int [na + nb];
	
	for (int i = 0; i < na; i++)
		newArr[i] = a[i];
	for (int i = 0; i < nb; i++)
		newArr[i + na] = b[i];
		
	return newArr; 
}

int* merge2Arrays(int* a, int* b, int na, int nb, int&nc)
{
	nc = na + nb;
	int *c = new int[nc];
	
	int i = 0, j = 0, k = 0;
	while (i < nc)
	{
		if (j >= na)
			c[i++] = b[k++];
		else if (k >= nb)
			c[i++] = a[j++];
		else
			c[i++] = (a[j] > b[k]) ? b[k++] : a[j++];
	}
	return c;
}

void generateMatrix1(int** &A, int &length, int &width){
	cin >> length >> width;
	A = new int *[length];
	for (int i = 0; i < length; i++){
		A[i] = new int [width];
		for (int j = 0; j < width; j++){
			A[i][j] = rand() % 90 + 10;
		}
	}
}

void print2DMatrix(int **A, int length, int width){
	for (int i = 0; i < length; i++){
		for (int j = 0; j < width; j++){
			cout << A[i][j] << " ";
		}
		cout << endl;
	}
}

void swapRows(int **a, int length, int width, int rowOne, int rowTwo) {
	swap(a[rowOne], a[rowTwo]);
}
int** findSubmatrix(int** a, int length, int width, int length_, int width_){
	int row = 0, col = 0;
	int maxSum = 0;
	for (int i = 0; i <= length - length_; i++){
		for (int j = 0; j <= width - width_; j++){
		
			int sum = 0;
			for (int k = i; k < i + length_; k++){
				for (int z = j; z < j + width_; z++)
					sum += a[k][z];
			
		if (sum > maxSum){
			maxSum = sum;
			row = i;
			col = j;
		}
		}
		}
	}
	int** matrix = new int*[length_];
	for (int i = 0; i < length_; i++)
		matrix[i] = new int[width_];
	for (int i = row; i < row + length_; i++){
		for (int j = col; j < col + width_; j++)
			matrix[i - row][j - col] = a[i][j];
	}
	return matrix;
}
int SentinelLinearSearch(int *a, int n, int key)
{
	if (a[n - 1] == key)
		return n - 1;
	int last = a[n - 1];
	int i = 0;
	a[n - 1] = key;
	while (a[i] != key)
		i++;
	a[n - 1] = last;
	if (i < n - 1 || a[n - 1] == key)
		return i;
	return -1;
}
int BinarySearch(int* a, int n, int key){
	
	int low = 0, high = n -1;
	while(low <= high){
		int mid = low + (high - low) / 2;
		if(a[mid] == key)
			return  mid;
		if(a[mid] > key)
			high = mid - 1;
		else low = mid + 1;
	}
	return -1;
}

int RecursiveBinarySearch(int* a, int left, int right, int key){
	int mid = (left + right) / 2;
	
	if ( a[mid] == key)
		return mid;
		
	if (a[mid] > key)
		return RecursiveBinarySearch(a, left, mid - 1, key);
		
	return RecursiveBinarySearch(a, mid + 1, right, key);
}
int Pow(int x, int n)
{
	if(n == 0) return 1;
	else
	return x * Pow(x, n-1);
}
int num_of_digits(int n)
{
	if(n < 10)
		return 1;
	return 1 + num_of_digits(n / 10);
}
int even(int n)
{
	if (n == 0)
		return true;
	if ((n % 10) % 2 != 0)
		return false;
	return even(n / 10);
}

int divisorCommon(int a, int b, int divisor = 1, int count = 0){
	if(divisor > a || divisor > b) return count;
	
	if(a % divisor == 0 && b % divisor == 0) ++ count;
	return  divisorCommon(a, b, divisor + 1, count);
}

int GCD (int a, int b)
{
	if (b == 0)
		return a;
	return GCD(b, a % b);
}

int LCM (int a, int b)
{
	return (a * b) / GCD (a, b);
}

int main(){
	srand(time(0));
//	int* a;
////	int* b;
//	int na,nb,nc;
////	int length, pos;
//	inputArray(a, na);
////	inputArray(b, nb);
//	sort(a, a + na);
////	sort(b, b + nb);
////	
//	printArray(a, na);
////	printArray(b, nb);
////	
////	int * newArr = merge2Arrays(a, b, na, nb, nc);
////	printArray(newArr, nc);
//	
////	swapArrays(a, b, na, nb);
////	printArray(a, na);
////	printArray(b, nb);
////	int* b = findLongestAscendingSubarray( a, n, length);
////	printArray(b, length);
//
//	//int **a = NULL;
//	//int length, width;
//	//generateMatrix1(a, length, width);
////	print2DMatrix(a, length, width);
//	//int rowOne, rowTwo;
//	//cin>>rowOne>>rowTwo;
//	//swapRows(a, length, width, rowOne, rowTwo);
////	cout<<"\n";
//	//int** matrix = findSubmatrix(a,length,width,3,3);
//	
//	//print2DMatrix(matrix, 3, 3);
//
//	cout << RecursiveBinarySearch(a, 0, na - 1, a[5]);
//	cout << Pow(2,8);
//	cout << num_of_digits(1453578);
//	cout << even(2222);
	cout << LCM(25, 35);
	return 0;
}
