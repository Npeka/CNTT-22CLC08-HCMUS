#include <iostream>
#include <queue>
#include<vector>
using namespace std;

struct Node{
	int key;
	Node* left;
	Node* right;
};

Node* createNode(int data){
	return new Node{data, NULL, NULL};
	
}

void Insert(Node* &root, int x ){
	if(root == NULL){
		root = createNode(x);
		return;
	}
	if(x < root->key)
		Insert(root->left, x);
	if (x > root->key)	
		Insert(root->right, x);
}

Node* createTree(int a[], int n){
	Node* root = NULL;
	for (int i = 0; i < n; i++)
		Insert(root, a[i]);
		
	return root;	
}
void NLR(Node* pRoot)
{
	if(pRoot != NULL)
	{
		cout << pRoot->key << " ";
		NLR(pRoot->left);
		NLR(pRoot->right);
	}
}


void LNR(Node* pRoot)
{
	if(pRoot != NULL)
	{
		
		LNR(pRoot->left);
		cout << pRoot->key << " ";
		LNR(pRoot->right);
	}
}
void LRN(Node* pRoot)
{
	if(pRoot != NULL)
	{
		
		LRN(pRoot->left);
		LRN(pRoot->right);
		cout << pRoot->key << " ";
	}
}
void levelOrder(Node* pRoot){
	if(pRoot == NULL) return;
	queue<Node*> q;
	q.push(pRoot);
	
	while(!q.empty()){
		
		Node* temp = q.front();
		q.pop();
		cout << temp->key <<" ";
		if(temp->left && temp->right){
			q.push(temp->left);
			q.push(temp->right);
		}else if(temp->left){
			q.push(temp->left);
			
		}else if(temp->right){
			q.push(temp->right);
		}
	}
}
int Height(Node *root)
{
	if(root == NULL) return 0;
	return max(Height(root->left),Height(root->right)) + 1;
}

int countNode(Node* root)
{
	if(root == NULL)
	return 0;
	
	return 1 + countNode(root->left) + countNode(root->right);
}

int sumNode(Node* root)
{
	if(root == NULL)
	return 0;
	
	return root->key + sumNode(root->left) + sumNode(root->right);
}
Node* Search(Node* root, int x)
{
	if (root == NULL || root->key == x)
		return root;
	if (root->key > x)
		return Search(root->left, x);
	return Search(root->right, x);
}
void Remove(Node* &pRoot, int x)
{
	if(pRoot == NULL)
		return;
	if(x < pRoot->key)
		Remove(pRoot->left, x);
	else if(x > pRoot->key)
		Remove(pRoot->right, x);
	else
	{
		if(pRoot->left == NULL && pRoot->right == NULL)
		{
			delete pRoot;
			pRoot = NULL;
		}
		else if(pRoot->left != NULL && pRoot->right != NULL)
		{
			Node *successor = pRoot->right;
			while(successor->left != NULL)
				successor = successor->left;
			swap(pRoot->key, successor->key);
			Remove(pRoot->right, x);
		}
		else
		{
			Node *child = pRoot->left;
			if(pRoot->right != NULL)
				child = pRoot->right;
			*pRoot = *child;
			delete child;
			child = NULL; 
		}
	}
}

void removeTree(Node* &root)
{
	if (root == NULL)
	{
		return;
	}
	
	if (root -> left != NULL)
	{
		removeTree(root -> left);
	}
	if (root -> right != NULL)
	{
		removeTree(root -> right);
	}
	
	Node* temp = root;
	root = NULL;
	delete temp;
}
 int heightNode(Node* pRoot, int value)
 {
 	if(pRoot == NULL)
 		return -1;
 	if(pRoot->key == value)
 		return Height(pRoot);
 	if(value < pRoot->key)
 		return heightNode(pRoot->left, value);
 	else 
 		return heightNode(pRoot->right, value);
 }
 int getLevelUtil(Node * root, int data, int level) {
 	if (root == NULL) return 0;
 	if (root->key == data) return level;
 	int downlevel = getLevelUtil(root->left, data, level + 1);
 	if (downlevel != 0) return downlevel;
 	downlevel = getLevelUtil(root->right, data, level + 1);
 	return downlevel;
 }
 int Level(Node *root, Node *p) {
 	return getLevelUtil(root, p->key, 1);
 }
 
int countLeaf(Node* pRoot){
	if(!pRoot) return 0;
	if(!pRoot->right && !pRoot->left) return 1;
	return countLeaf(pRoot->right) + countLeaf(pRoot->left);
}
int countLess(Node* pRoot, int x) {
	if(pRoot == NULL)
		return 0;
	if(pRoot->key >= x)
		return countLess(pRoot->left, x);
	return 1 + countLess(pRoot->left, x) + countLess(pRoot->right, x);
}

int countGreat(Node *pRoot, int x)
{
	if(pRoot == NULL)
		return 0;
	if(pRoot->key <= x)
		return countGreat(pRoot->right, x);
	return 1 + countGreat(pRoot->left, x) + countGreat(pRoot->right, x);
}

void toArray(vector <int> &a, Node* pRoot){
	if (pRoot == NULL)
		return;
		
	toArray(a, pRoot->left);
	a.push_back(pRoot->key);
	toArray(a, pRoot->right);
}

bool isBST(Node* pRoot){
	vector <int> a;
	toArray(a, pRoot);
	for (int i = 1; i < (int)a.size(); ++i)
		if (a[i] < a[i-1])
			return false;
	return true;
}

bool isFull (Node* pRoot)
{
	if (pRoot == NULL)
		return true;
		
	else
	{
		if (pRoot->left == NULL && pRoot->right != NULL)
			return false;
		if (pRoot->left != NULL && pRoot->right == NULL)
			return false;
		return true && isFull(pRoot->left) && isFull (pRoot->right);
	}
}

bool isFullBST(Node* pRoot)
{
	return isBST(pRoot) && isFull(pRoot);
}

const int INF = 1E9;
int findMin(Node* pRoot) {
	if (pRoot == NULL) return INF;
	
	int leftNode = findMin(pRoot->left);
	int rightNode = findMin(pRoot->right);
	
return min(pRoot->key, min(leftNode, rightNode));
}

int findMax(Node* pRoot) {
	if (pRoot == NULL) return -INF;
	
	int leftNode = findMax(pRoot->left);
	int rightNode = findMax(pRoot->right);
return max(pRoot->key, max(leftNode, rightNode));
}

bool isBST2(Node* pRoot) {
	if (pRoot == NULL) return true;
	
	int curNode = pRoot->key;
	if (pRoot->left != NULL && findMax(pRoot->left) > curNode) return false;
	if (pRoot->right != NULL && findMin(pRoot->right) < curNode) return false;
	
	if (isBST2(pRoot->left) == false || isBST2(pRoot->right) == false) return false;
	
return true;	
}

bool isBST3(Node * root, int minval, int maxval)
{
	if (root == NULL) return true; 
	if (root->key < minval || root->key > maxval)	return false; 
	
	return isBST3(root, minval, root->key - 1) && isBST3(root, root->key + 1, maxval);
}

bool isBST3n(Node * root)
{
	return isBST3(root, INT_MIN, INT_MAX);
}

void insert2(Node *&pRoot, int data)
{
	Node*newNode = createNode(data);
	
	if(pRoot == NULL)
		pRoot = newNode;
	else
	{
		Node *curNode = pRoot;
		Node *prev = NULL;
		
		while(curNode != NULL)
		{
			if (data < curNode->key)
			{
				prev = curNode;
				curNode = curNode->left;
			}
			else
			{
				prev = curNode;
				curNode = curNode->right;
			}
		}
			
			
		if(data < prev->key)
			prev->left = newNode;
		else
			prev->right = newNode;
		
	}
	//cout <<pRoot->key;
}

void delete2 (Node* root, int key)
{
	Node* curNode = root;
	Node* prevNode = NULL;
	while (curNode != NULL && curNode->key != key)
	{
		prevNode = curNode;
		if (key > curNode->key)
			curNode = curNode->right;
		else
			curNode = curNode->left;
	}
	
	if (curNode == NULL)
		cout << "Cannot find";
		
	if (curNode->left == NULL || curNode->right == NULL)
	{
		Node* newCurr;
		if (curNode->left == NULL)
			newCurr = curNode->right;
		else
			newCurr = curNode->left;
			
		if (prevNode == NULL)
			prevNode = newCurr;
		
		if (curNode == prevNode->left)
			prevNode->left = newCurr;
		else
			prevNode->right = newCurr;
			
		delete curNode;
	}
	
	else 
	{
		Node* p = NULL;
		Node* temp;
		
		temp = curNode->right;
		while (temp->left != NULL)
		{
			p = temp;
			temp = temp->left;
		}
		
		if (p != NULL)
			p->left = temp->right;
		else
			curNode->right = temp->right;
			
		curNode->key = temp->key;
		delete temp;
	}
}

int main(){
	int a[5]={6, 4, 9, 3, 10};
	//Node* root = createTree(a, 5);
	Node* root = NULL;
	for(int i = 0; i < 5; ++i)
		insert2(root,a[i]);
	LNR(root);
	delete2(root, 9);
	cout << endl;
	LNR(root);
//	cout<< Search(root, 9)->key;
	
//	cout << endl;
//	Node * p = new Node;
//	p->key = 6;
//	p->left = p->right = NULL;
	//cout << countGreat(root,4);
	/*
	Node* p = Search(root, 4);
	p->right = createNode(7);
	LNR(root); cout<<"\n";
	
	cout << isBST3n(root);
	removeTree(root);
	*/
}
