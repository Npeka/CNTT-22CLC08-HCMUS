#include <iostream>

using namespace std;

struct Node {
	int key;
	Node* next;
};

struct Stack {
	Node* pHead;
};

struct Queue {
	Node* front;
	Node* rear;
};

bool isEmpty (Queue q)
{
	return (q.front == NULL);
}

Node* createNode(int data) {
	Node* newNode = new Node;
	newNode->key = data;
	newNode->next = NULL;
return newNode;
}

void push(Stack &s, int data) {
	if (s.pHead == NULL) {
		Node* newNode = createNode(data);
		s.pHead = newNode;
		return;
	}
	
	Node* newNode = createNode(data);
	newNode->next = s.pHead;
	s.pHead = newNode;
}

int pop(Stack &s){
	if (s.pHead == NULL)
	return 0;
	
	Node* curNode = s.pHead;
	int output = curNode -> key;
	s.pHead = s.pHead -> next;
	delete curNode;
	return output;
	

}

void showStack(Stack s) {
	for (Node* curNode = s.pHead; curNode != NULL; curNode = curNode->next) {
		cout<<curNode->key<<" ";
	}
}

void enqueue (Queue &q, int key)
{
	Node* newNode = createNode(key);
	if (q.front == NULL)
	{
		q.front = q.rear = newNode;
		return;
	}
	
	q.rear->next = newNode;
	q.rear = newNode;
}

void deQueue (Queue &q)
{
	if (isEmpty(q))
	{
		cout << "Queue is empty";
		return;
	}
	
	Node* temp = q.front;
	q.front = q.front -> next;
	if(q.front == NULL)
	{
		q.rear = NULL;
	}
	delete temp;
}

void showQueue(Queue q) {
	for (Node* curNode = q.front; curNode != NULL; curNode = curNode->next) {
		cout<<curNode->key<<" ";
	}
}

int main() {
	Stack s;
	s.pHead = NULL;
	
	Queue q;
	q.front = q.rear = NULL;
	
	//for (int i = 0; i < 10; ++i) push(s, i);
	//showStack(s);
	//cout << "\n"<< pop(s) << "\n";
	//showStack(s);
	
	for (int i = 0; i < 10; ++i)
		enqueue(q, i);
	
	deQueue(q);
	showQueue(q);	
}
