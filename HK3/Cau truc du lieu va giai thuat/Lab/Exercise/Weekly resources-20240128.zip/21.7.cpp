#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <string>
#include <cmath>

using namespace std;

int somesum(int n, int &assign, int &compare) {
	int sum = 0, i = 1, j;
	assign += 2;
	
	while (++compare && i <= n) {	
		j = n - i;
		++assign;
		
		while (++compare && j <= i*i){
			sum = sum + i*j;
			j++;
			assign += 2;			
		}
		++i;
		++assign;
	}
	
	return sum;
}


int squaresum_recursion(int n, int &compare, int &assign) {
	++compare; 
 	if (n < 1) return 0;
	else
	{
		assign = assign + 3;
		return n*n + squaresum_recursion(n-1, compare, assign);
	}
}

int majorEle(int a[], int n){
	int vote = 0, candi = -1;
	for (int i = 0; i < n; ++i){
		if (vote == 0){
			candi = a[i];
			vote = 1;
		}
		else{
			if (a[i] == candi)
				++vote;
			else --vote;
		}
	}
	int cnt = 0;
	for (int i = 0; i < n; ++i)
		if (a[i] == candi)
			++cnt;
	if (cnt > n/2)
		return candi;
	return -1;
}

int countOccur (string* a, int n, string x)
{
	int count = 0;
	for (int i = 0; i < n; ++i)
	{
		if (x == a[i])
			count++;
	}
	return count;
}

void wordcloud (string* a, int n)
{
	sort(a, a + n);
	for (int i = 1; i < n; ++i)
	{
		if (a[i] == a[i-1])
			continue;
		
		cout << a[i] << ": " << countOccur(a, n, a[i]) << endl;
	}
}

struct Pair{
	int i; 
	int j;
	
	Pair(int a, int b) : i(a), j(b) {}
};

Pair findBalanceHats(int left, int right, int a[], int n){
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			if(left + a[i] == right + a[j]) return Pair(i, j);
	
	return Pair(-1, -1);
	
}

//LAB 4



struct Company
{
string name;
string profit_tax;
string address;
};


vector<Company> ReadCompanyList(string file_name){
	vector<Company> v(1);
	ifstream ifs;
	Company temp;
	
	ifs.open(file_name);
	
	if(!ifs.is_open()){
		cout << "Access denied \n";
		return v;
	}
	
	for (int i = 0; !ifs.eof(); i += 1){
		getline(ifs, temp.name, '|');
		getline(ifs, temp.profit_tax, '|');
		getline(ifs, temp.address);
		
		v.push_back(temp);
	}
	
	ifs.close();
		
	return v;
}

void printList(vector<Company> v){
	
	for (int i = 0; i < v.size(); i += 1){
		cout << "\n" << v[i].name << "\n" << v[i].profit_tax << "\n" << v[i].address << "\n";
	}
}

long long power(int x, int y){
	long long n = 1;
	long long m = pow(10, 9) + 9;
	for(int i = 0; i < y; i++){
		n = n * x;
		n = n % m;
	}
	return n;
}

long long HashString(string company_name){
	long long output = 0;
	int p = 31;
	long long m = pow(10, 9) + 9;
	if(company_name.length() <= 20){
		for(int i = 0; i < company_name.length(); i++){
			long long temp = ((int)company_name[i] * power(p, i)) % m;
			output = output + temp;
		}
	}
	
	else{
		for(int i = 0; i < 20; i++){
			long long temp = ((int)company_name[company_name.length() - i - 1] * power(p, company_name.length() - i - 1)) % m;
			output = output + temp;
		}
	}
	output = output % m;
	return output;
}
int HashFunction(string name){
	int hashValue = HashString(name);
	return (int) hashValue % 2000;
}
void insert(Company* hash_table, Company company){
	int index = HashFunction(company.name);
	while(hash_table[index].name != ""){
		if(hash_table[index].name == company.name){
			return;
		}
		index++;
		if(index == 2000)
			index = 0;
	}
	hash_table[index] = company;
}

Company* CreateHashTable(vector<Company> list_company)
{
	Company *hashTable = new Company[2000];
	for(int i = 0; i < list_company.size(); ++i)
	{
		insert(hashTable, list_company[i]);
	}
	
	return hashTable;
}
Company* Search(Company* hash_table, string company_name) {
	int index = HashFunction(company_name);
	while(hash_table[index].name != "") {
		if (hash_table[index].name == company_name)
			return &hash_table[index];
		index++;
		if (index == 2000)
			index = 0;
	}
}

void deleteComapany (Company * hash_table, string name)
{
	int index = HashFunction (name);
	while(hash_table[index].name != "") {
		if (hash_table[index].name == name)
			break;
		index++;
		if (index == 2000)
			index = 0;
		}
	if (hash_table[index].name == "")
		return;
	while (hash_table[index].name != "")
	{
		hash_table[index] = hash_table[(index + 1 == 2000 ? 0 : index + 1)];
		index = (index + 1 == 2000 ? 0 : index + 1);
	}
}

int main(){
	/*int  assign = 0, compare = 0;
	cout << "n" <<  "		assignments" <<  "	comparisions" << endl;
	
	for(int i = 0; i <= 500; i += 25)
	{
		assign = compare = 0;
		squaresum_recursion(i, assign, compare);
		cout << i << "		" << assign << "		" <<compare << endl;
	}*/
	//srand(time(0));
	//int a[50];
	//for (int i = 0; i < 10; ++i)
		//a[i] = rand() % 10;
	//cout << majorEle(a, 50);
	
//	ifstream fIn;
//	string temp;
//	fIn.open ("data.txt");
//	getline(cin, temp, '\n');
//	
//	int n = temp.length();
//	string* a = new string [n];
//	
//	for (int i = 0; i < n; ++i)
//		if (temp[i] == '.' || temp[i] == ',')
//			temp[i] = ' ';
//			
//	stringstream ss (temp);
//	for (int i = 0; i < n; ++i)
//		ss >> a[i];
//	fIn.close ();
//	for (int i = 0; i < n; ++i)
//	{
//		
//		cout << a[i] << " ";
//	}
//	
//	cout << endl;
//	wordcloud(a, n);

/*
	int n = 10;
	int left = 10, right = 8;
	int a[n] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
	
	Pair res = findBalanceHats(left, right, a, n);
	cout << left << " " << right << endl;
	cout << res.i << " " << res.j;
	
	
*/
//	vector<Company> v;
//	v = ReadCompanyList("MST.txt");
//	printList(v);

	long long hash = HashString("CONG TY CO PHAN THUONG MAI CHAU DUC PHAT");
	cout<<hash;


	
}
