#include <iostream>
using namespace std;

struct DNode{
	int key;
	DNode* next;
	DNode* prev;
};
struct List{
	DNode* pHead;
	DNode* pTail;
};
int reverse (int a, int b)
{
	if (a == 0)
		return b ;
	b = b * 10 + a % 10;
	return reverse (a / 10, b);
}

int fibonaci (int n)
{
	if (n == 0)
	{
		return 0;
	}
	if (n == 1)
	{
		return 1;
	}
	else
	{
		return fibonaci(n - 1) + fibonaci (n - 2);
	}
}

void printPermutation(string s, int i, int n){
	if (i == n){
		for (int j = 0; j < n; ++j)
			cout << s[j];
		cout << "\n";
	}
	else{
		for (int j = 0; j < n; ++j){
			swap(s[i], s[j]);
			printPermutation(s, i+1, n);
			swap(s[i], s[j]);
		}
	}
}

DNode* createNode( int data)
{
	DNode* n = new DNode;
	n->key = data;
	n->next = NULL;
	n->prev = NULL;
	return n;
}

void addHead(List &L, int data)
{
	if(L.pHead != NULL)
	{
		DNode* newNode = createNode(data);
		newNode->next = L.pHead;
		L.pHead->prev = newNode;
		L.pHead = newNode;
	}
	else{
		L.pHead = L.pTail = createNode(data);
	}

}

void print(List L)
{
	DNode* curNode = L.pHead;
	while(curNode != NULL)
	{
		cout << curNode->key << " ";
		curNode = curNode->next;
	}
	cout << endl;
}

void addTail(List &list, int key)
{
	DNode* newNode = new DNode;
	newNode->key = key;
	newNode->next = NULL;
	newNode->prev = NULL;
	if (list.pHead == NULL)
	{
		list.pHead = newNode;
		list.pTail = newNode;
	}
	else
	{
		list.pTail->next = newNode;
		newNode->prev = list.pTail;
		list.pTail = newNode;
	}
}

void delHead(List &L)
{
	if(L.pHead == NULL)
		return;
	
	DNode *nextNode = L.pHead->next;
	delete L.pHead;
	L.pHead = nextNode;
	if(nextNode != NULL)
		L.pHead->prev = NULL;
}

void delTail(List &L)
{
	if(L.pHead == NULL)
		return;
	
	DNode *preNode = L.pTail->prev;
	delete L.pTail;
	L.pTail = preNode;
	if(L.pTail != NULL)
		L.pTail->next = NULL;
}
bool addBefore(List& lst, int data, int val) {
	if (lst.pHead == NULL)
		return false;
	DNode* curNode = lst.pHead;
	while (curNode != NULL && curNode->key != val)
		curNode = curNode->next;
	if (curNode == NULL)
		return false;
	if (curNode->prev == lst.pTail) {
		addHead(lst, data);
		return true;
	}
	DNode* prevNode = curNode->prev;
	DNode* newNode = createNode(data);
	prevNode->next = newNode;
	newNode->prev = prevNode;
	newNode->next = curNode;
	curNode->prev = newNode;
	return true;
		
}
bool addAfter(List& lst, int data, int val) {
	DNode* newNode = createNode(data);
	if(lst.pHead == NULL){
		lst.pHead = lst.pTail = createNode(data);
		return true;
	}
	DNode* cur = lst.pHead;
	while(cur != NULL && cur->key != val){
		cur = cur->next;
	}
	if(cur == NULL)
		return false;
	if(cur->next == NULL){
		addTail(lst, data);
		return true;
	}
	newNode->next = cur->next;
	cur->next->prev = newNode;
	cur->next = newNode;
	newNode->prev = cur;
	
	return true;
}

bool addPos(List &lst, int data, int pos) {
	DNode* newNode = createNode(data);
	
	if (pos == 0) {
		if (lst.pHead == NULL) {
			lst.pHead = lst.pTail = newNode;
			return true;
		} else {
			addHead(lst, data);
			return true;
		}
	}
	
	int len = 0;
	for (DNode* curNode = lst.pHead; curNode != NULL; curNode = curNode->next) ++len;
	
	if (pos > len) return false;
	
	if (pos == len) {
		addTail(lst, data);
		return true;
	}
	
	int cnt = 0;
	DNode* prevNode = NULL;
	DNode* curNode = lst.pHead;
	DNode* nextNode = lst.pHead->next;
	while (cnt < pos) {
		prevNode = curNode;
		curNode = nextNode;
		nextNode = nextNode->next;
		++cnt;
	}
	
	prevNode->next = newNode;
	newNode->prev = prevNode;
	newNode->next = curNode;
	curNode->prev = newNode;
}
void removeBefore(List &L, int val)
{
	if (L.pHead == NULL || L.pHead->next == NULL)
		return;
	if (L.pHead ->next->key == val)
	{
		DNode * temp = L.pHead;
		L.pHead = L.pHead->next;
		L.pHead->prev = NULL;
		delete temp;
		return;
	}
	DNode * current = L.pHead ->next ->next;
	while (current != NULL)
	{
		if (current-> key == val)
		{
			DNode * remove = current->prev;
			remove ->prev->next= current;
			current->prev = remove->prev;
			delete remove;
			return;
		}
		current = current -> next;
	}
}
void removeAfter(List& l, int val){
	DNode* current = l.pHead;
	if (current == NULL)
		return;
	while(current->next != NULL && current->key != val){
		current = current->next;
	}
	if (current == NULL || current->next == NULL)
		return;
	DNode* remove = current->next;
	current->next = remove->next;
	if (remove->next == NULL)
		l.pTail = current;
	else 
		remove->next->prev = current;
	delete remove;
}
void removeDuplicate(List& L)
{
	if(L.pHead == NULL  || L.pHead->next == NULL) return;
	DNode *cur = L.pHead;
	while(cur != NULL)
	{
		DNode *run = cur->next;
		while(run != NULL)
		{
			if(run->key == cur->key)
			{
				DNode* tmp = run;
				run->prev->next = run->next;
				if(run->next != NULL)
					run->next->prev = run->prev;
				else L.pTail = run->prev;
				run = run->next;
				delete tmp;
			}
			else run = run->next;
		}
		cur = cur->next;
	}
}
void printLL (List list)
{
	DNode* curNode = list.pTail;
	while(curNode != NULL)
	{
		cout << curNode->key << "->";
		curNode = curNode->prev;
	}
	cout << endl;
}

void removePos(List &list, int pos){
	if (list.pHead == NULL || pos < 0)
		return;
		
	if (pos == 0){
		delHead(list);
		return;
	}
	
	DNode *cur = list.pHead;
	for (int i = 1; i < pos; ++i){
		cur = cur->next;
		if (cur == NULL)
			return;
	}
	
	if (cur->next == NULL){
		delTail(list);
		return;
	}
	
	cur->next->prev = cur->prev;
	cur->prev->next = cur->next;
	delete cur;
	return;
}

void removeX(List &l, int x)
{
	if(l.pHead != NULL)
	{
		DNode *cur = l.pHead;
		int count = 0;
		while (cur != NULL)
		{
			if (cur->key == x)
			{
				cur = cur->next;
				removePos(l, count);
			}
			else
			{
				count ++;
				cur = cur->next;
			}
		}
	}
}

int main()
{
	//int n;
	//cout << fibonaci (10);
	//cout << reverse(123, 0);
	//string a = "ABCD";
	//printPermutation(a, 0, 4);
	List L;
	L.pHead = NULL;
	L.pTail = NULL;
	for(int i = 0; i < 10; i++)
		addTail(L, 1);
	
	addTail(L,0);
	printLL(L);
	//delHead(L);
	//delTail(L);
	//removeBefore(L, 4);
//	removePos(L, 3);
	removeX(L, 1);
	printLL(L);
	return 0;
}
