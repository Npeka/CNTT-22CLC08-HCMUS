#include <iostream>
#include <math.h>
using namespace std;

struct Node
{
	int key;
	Node *left, *right;
};

Node *createNode(int data)
{
	Node *newnode = new Node;
	newnode->left = newnode->right = NULL;
	newnode->key = data;
	return newnode;
}

int height(Node *root)
{
	if (root == NULL)
		return 0;
	else
	{
		int left = height(root->left);
		int right = height(root->right);
		return (left < right) ? left + 1 : right + 1;
	}
}

void leftRotate(Node *&root)
{
	Node *p = root->left;
	root->left = p->left;
	p->left = root;	
	
	root = p;
}

void rightRotate(Node *&root)
{
	Node *p = root->right;
	root->right = p->right;
	p->left = root;
	
	root = p;
}

void RebalanceAVL(Node*&root){
	int balance = height(root->left) - height(root->right);
	
	// MCB trai
	if (balance >= 2)
	{
		// MCB trai trai
		if (height(root->left->left) >= height(root->left->right))
			rightRotate(root);
		else // MCB trai phai
		{
			leftRotate(root->right);
			rightRotate(root);
		} 
	}
	
	// MCB phai
	else if (balance <= -2)
	{
		// MCB phai phai
		if (height(root->right->right) >= height(root->right->left))
			leftRotate(root);
		else // MCB phai trai
		{
			rightRotate(root->left);
			leftRotate(root);
		}
	}
}

void Insert(Node *&root, int data)
{
	if (root == NULL)
		root = createNode(data);
	if (data > root->key)
	{
		Insert(root->right, data);
	}
	else if (data < root->key)
	{
		Insert(root->left, data);
	}
	else
		return;
		
	RebalanceAVL(root);
	return;
}

void RemoveLeaf(Node*&leaf){
	delete leaf;
}

void RemoveLink(Node*&root){//Node having a child that has only one child
	if (root -> left != NULL){
		if (root -> left -> left != NULL){
			Node* temp = root -> left -> left;
			delete root -> left;
			root -> left = temp;
		}
		else{
			Node* temp = root -> left -> right;
			delete root -> left;
			root -> left = temp;	
		}
		
	}
	else{
		if (root -> right -> left != NULL){
			Node* temp = root -> right -> left;
			delete root -> right;
			root -> right = temp;
		}
		else{
			Node* temp = root -> right -> right;
			delete root -> right;
			root -> right = temp;	
		}
		
	}
	
}

void del(Node*&root, Node*& a){
	if (root -> right) del(root -> right, a);
	else{
		a -> key = root -> key;
		a = root;
		root = root -> left;
	}
	
}

void Remove(Node *&root, int data){
	if (root == NULL){
		cout << "tree is empty";
		return;
	}
		
	if (data > root->key)
	{
		Remove(root->right, data);
	}
	else if (data < root->key)
	{
		Remove(root->left, data);
	}
	else if (data == root->key)//Found
	{
		Node* replacement = root;
		if (replacement -> right == NULL) root = replacement -> left;
		else if (replacement -> left == NULL) root = replacement -> right;
		else del(root -> left, replacement);
		delete replacement;
	}
	else 
		return;
	RebalanceAVL(root);
}


void NLR(Node *root)
{
	if (root != NULL)
	{
		cout << root->key << " ";
		NLR(root->left);
		NLR(root->right);
	}
}


bool isBST(Node* root){
	if(!root)
		return 1;
	if(root->left == NULL && root->right == NULL)
		return 1;
		
	if(root->left == NULL){
		if(root->right->key < root->key)
			return 0;
			
		if(isBST(root->right) == 0)
			return 0;
	}
	
	else if(root->right == NULL){
		if(root->left->key > root->key)
			return 0;
			
		if(isBST(root->left) == 0)
			return 0;
	}
	else{
		if(root->right->key < root->key || root->left->key > root->key)
			return 0;
		if(isBST(root->right) == 0)
			return 0;	
		if(isBST(root->left) == 0)
			return 0;		
	}
	return 1;
}



bool isAVL(Node* root){
	if(!root)
		return 1;
		
	if(isBST(root) == 0)
		return 0;
		
	int lh, rh; 
	lh = height(root->left);
	rh = height(root->right);
	
	if( abs(lh - rh) <= 1 && isAVL(root->left) && isAVL(root->right))
		return 1;
		
	return 0;
}


int main()
{
	Node *root = NULL;
	for (int i = 0;i < 10; i++)
	{
		Insert(root, i);
	}
	NLR(root);
	

	cout << endl << isAVL(root);

	return 0;
}
