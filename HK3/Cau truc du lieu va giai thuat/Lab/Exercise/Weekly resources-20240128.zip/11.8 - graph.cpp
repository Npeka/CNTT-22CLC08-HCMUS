#include<iostream>
#include<fstream>
#include<vector>
#include <queue>
using namespace std;

vector< vector<int> > adjMatrixToList(string filename, int &n){
	ifstream ifs;
	ifs.open(filename.c_str());

	ifs >> n;
	vector< vector<int> > adj(n + 1);
	int a[100][100] = {0};
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			ifs >> a[i][j];
	ifs.close();

	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j)
			if (a[i][j] == 1)
				adj[i].push_back(j);
	}

    for (int i = 1; i <= n; ++i){
	    cout<<i<<": ";
		for(int j = 0; j < adj[i].size(); ++j)
			cout << adj[i][j] << " ";
		cout << "\n";
	}

return adj;
}

bool checkDirected(vector< vector<int> > adj, int n) {
    bool flag = false;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (i == j) continue;
            for (int k = 0; k < (int)adj[i].size(); ++k) {
                for (int y = 0; y < (int)adj[j].size(); ++y) {
                if (adj[i][k] == adj[j][y]) flag = true;
                }
            }
        }
    }
return flag;
}
bool visited[1000];

void DFS(vector< vector<int> > adj, int u) {
    visited[u] = true;
    for (int i = 0; i < (int)adj[u].size(); ++i) {
            int it = adj[u][i];
            if(visited[it] == false)
                DFS(adj, it);
    }
}

int count_connected(vector< vector<int> > adj){
    int count = 0;
    for(int i = 1; i < adj.size(); i += 1)
    {
        if(visited[i] == false)
            DFS(adj, i),
            count += 1;
    }
    return count;
}

bool span_tree[1000];
void DFS_spantree(vector< vector<int> > adj, int u) {
    span_tree[u] = true;
    for (int i = 0; i < (int)adj[u].size(); ++i) {
        int v = adj[u][i];
        if (span_tree[v] == false)
            DFS_spantree(adj, v);
    }
}

void BFS_spantree(vector< vector<int> > adj, int s, int n) {
    vector<bool> vis(n, false);
    queue<int> q;
    q.push(s);
    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int i = 0; i < (int)adj[u].size(); ++i) {
            int v = adj[u][i];
            if (span_tree[v] == false) {
                q.push(v);
                span_tree[v] = true;
            }
        }
    }
}

int main(){
	int n = 0;
	vector< vector<int> > adj = adjMatrixToList("input.txt", n);
    if (checkDirected(adj, n) == false) cout<<"Undirected Graph";
    else cout<<"Directed Graph";
    cout<<"\n";
    cout << "So thanh phan lien thong: " <<  count_connected(adj)<<endl;

    //spanning tree
    for (int i = 1; i <= n; ++i) span_tree[i] = false;
    DFS_spantree(adj, 1);
    cout<<"DFS tree: \n";
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j < (int)adj[i].size(); ++j) {
            int v = adj[i][j];
            if (span_tree[i] == true && span_tree[v] == true)
                cout<<i<<" "<<v<<"\n";
        }
    }
    for (int i = 1; i <= n; ++i) span_tree[i] = false;
    BFS_spantree(adj, 1, n);
    cout<<"BFS tree: \n";
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j < (int)adj[i].size(); ++j) {
            int v = adj[i][j];
            if (span_tree[i] == true && span_tree[v] == true)
                cout<<i<<" "<<v<<"\n";
        }
    }
}
