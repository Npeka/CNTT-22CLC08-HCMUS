#include<iostream>
#include<string>
#include<fstream>
#include<sstream>
#include<vector>

using namespace std;

struct Examinee
{
	string id;
	float math, literature, physic, chemistry, biology, history, geography, civic_education, natural_science,
	social_science, foreign_language;
};

Examinee readExaminee(string line_info){
	Examinee examinee;
	stringstream ss(line_info);
	string field;
	
	getline(ss, examinee.id, ',');
	getline(ss, field, ',');
	
	getline(ss, field, ',');
	examinee.math = field.empty()? 0.0f : stof(field);
	
	getline(ss, field, ',');
	examinee.literature = field.empty()? 0.0f : stof(field);
	
	getline(ss, field, ',');
	examinee.physic = field.empty()? 0.0f : stof(field);
	
	return examinee;
}

vector<Examinee> readExamineeList(string file_name){
	vector<Examinee> examineeList;
	ifstream fileIn(file_name);
	
	if(fileIn.is_open()){
		string line;
		getline(fileIn, line);
		
		while(getline(fileIn, line)){
			Examinee examinee = readExaminee(line);
			examineeList.push_back(examinee);
		}
		
		fileIn.close();
	}
	return examineeList;
}

void writeTotal(vector<Examinee> examinee_list, string out_file_name){
//	ofstream fileOut(string out_file_name);
	for(int i = 0 ; i < examinee_list.size() ; i++){
		float total = examinee_list[i].math + examinee_list[i].literature + examinee_list[i].physic;
		cout<<examinee_list[i].id<<" "<<total<<endl;
	}
}
int main(){
	vector<Examinee> list = readExamineeList("data.txt");
	writeTotal(list, "output");
	system("pause");
	return 0;
}
